package Sucursales;

import Users.Usuario;
import Users.utils.constantes.Rol;
import Users.Empleados.GerenteSucursal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

public class SucursalAcueducto extends Sucursal{
    int idGerente = 1;
    static HashMap<Rol, ArrayList<Usuario>> empleados = new HashMap<>();

    GerenteSucursal gerenteAcueducto = new GerenteSucursal(idGerente,"Michelle", "Mandujano Chávez", LocalDate. of(2003,12,21),"Morelia","Michoacán",
            "CAMA001221MGTHNBA1","Calle Rio Mayo #456", this, 50000.00,Rol.GERENTE_SUCURSAL,LocalDate.of(2020, 01, 01), "gerente acueducto", "michelle_chavez");

    public SucursalAcueducto(String nombreSucursal, String direccionSucursal) {
        super( "Acueducto","Av. Acueducto #220");
    }

    public SucursalAcueducto(String nombreSucursal, String direccionSucursal, GerenteSucursal gerenteSucursal) {
        super(nombreSucursal, direccionSucursal);
        this.gerenteAcueducto = gerenteSucursal;
    }
    public GerenteSucursal getGerente() {
        return gerenteAcueducto;
    }


    @Override
    public String toString() {
        String gerenteInfo = "";
        if (getGerente() != null) {
            gerenteInfo = "Gerente: " + getGerente().getNombre() + " " + getGerente().getApellidos();
        } else {
            gerenteInfo = "La sucursal no tiene un gerente asignado.";
        }
        return "SucursalAcuedcuto{" +
                ", nombreSucursal='" + nombreSucursal + '\'' +
                ", direccionSucursal='" + direccionSucursal + '\'' +
                ", " + gerenteInfo +
                '}';
    }
    private static ArrayList<String> historialInversiones = new ArrayList<>();
//    public static final HashMap<Rol, Usuario> usuarios = new HashMap<>();
//    public SucursalAcueducto(String direccionSucursal, Gerente gerente) {
//        super(direccionSucursal, gerente);
//        this.gerente = gerente;
//    }
    public static final HashMap<Rol, ArrayList<Usuario>> getEmpleados() {
        return empleados;
    }

    public static void setHistorialInversiones(String registro) {
        historialInversiones.add(registro);
    }
}