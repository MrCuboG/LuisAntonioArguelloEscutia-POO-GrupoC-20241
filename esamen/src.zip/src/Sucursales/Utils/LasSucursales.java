package Sucursales.Utils;

public enum LasSucursales {
    MADERO,
    ACUEDUCTO;
}
