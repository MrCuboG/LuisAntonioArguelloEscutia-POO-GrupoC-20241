
import Sistemas.Sistema;


public class Main {
    public static void main(String[] args) {
        Sistema s = new Sistema();
        s.iniciarSistema();

    }
}
