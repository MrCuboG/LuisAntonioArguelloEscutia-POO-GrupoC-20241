package Users.utils.constantes;

import Sucursales.Sucursal;

public enum Rol {
    GERENTE_SUCURSAL,
    EMPLEADO,
    EJECUTIVO_CUENTA,
    CAPTURISTA,
    INVERSIONISTA,
    CLIENTE;
}