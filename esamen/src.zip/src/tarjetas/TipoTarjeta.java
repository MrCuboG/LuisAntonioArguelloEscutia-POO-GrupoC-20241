package tarjetas;

public enum TipoTarjeta {
    SIMPLICITY,
    PLATINO,
    ORO
}