package tarjetas;

public enum EstadoSolicitud {
    EN_PROCESO,
    APROBADA,
    RECHAZADA
}