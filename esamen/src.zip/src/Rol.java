public enum Rol {
    GERENTE,
    EMPLEADO,
    EJECUTIVO_CUENTA,
    CAPTURISTA,
    INVERSIONISTA,
    CLIENTE;
}