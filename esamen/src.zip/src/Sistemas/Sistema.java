package Sistemas;

import Sucursales.Sucursal;
import Sucursales.SucursalMadero;
//import Sucursales.SucursalMadero;
import Users.utils.constantes.Rol;

public class Sistema {
    Menus menus = new Menus();
    SucursalMadero sucursalMadero = new SucursalMadero(null, null);
    Sucursal sucursales = new Sucursal(null, null);
    Gerente gerente1 = new Gerente("a", "a", null, null, null, null, "a", "123", Rol.GERENTE, 123, null);
    Gerente gerente2 = new Gerente("a", "a", null, null, null, null, "q", "123", Rol.GERENTE, 123, null);
    public void iniciarSistema(){

        menus.inicioSesion();
    }
    public void verificarInicioSesion(){
    }
}
